1. support board
# GoldBull debug board
   - 10M/100M ethernet
   - SPI SD Card
     SPI: SPI1 (PA5,PA6,PA7). CS:PA4
